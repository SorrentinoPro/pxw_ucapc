# Uber Clean Air Plan Calculator

The Plug-in will allow users to select a car (out of the six Otto Car LTD have on their Rent 2 Buy scheme) and be able to select how much money they have on their Uber Clean Air fund, in order to see how much of a discount they can get on their weekly payments if they take out a car with Otto Car.
		
# Features:

Display the calculator with a Short code everywhere.

Responsive cross browser / Mobile friendly.

# How to use:

1) Download pxw_ucapc-master.zip

2) Unzip it and upload pxw-uber_clean_air_plan_calculator folder via Wordpress plug-in upload page then activate it.
   
3a) Navigate to one of the page or post via the administration panel and type... [pxw_ucapc] to load the plug in inside any text editor in order to initialize the short code. 

3b) The short code can be included anywhere via php including <?php echo do_shortcode('[pxw_ucapc]'); ?>

5) Finally Navigate to the published page / article and enjoy. 
